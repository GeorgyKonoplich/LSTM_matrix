import sys, os
import gensim
import pandas as pd
import numpy as np
from random import uniform

# Restore exact lemma_pos
def get_lemma_pos_representation(matrix, lemma_file, pos_file, lemma_id, pos_id):
    
    ind_to_lemma = pd.read_csv(lemma_file, sep='\t', header=None)
    ind_to_lemma.index = ind_to_lemma[0]
    del ind_to_lemma[0]
    lemma_dict = ind_to_lemma.to_dict()[1]

    ind_to_pos = pd.read_csv(pos_file, sep='\t', header=None)
    ind_to_pos.index = ind_to_pos[0]
    del ind_to_pos[0]
    pos_dict = ind_to_pos.to_dict()[1]
    
    lemma_pos_set = []
    new_matrix = matrix.reshape((matrix.shape[0]*matrix.shape[1], matrix.shape[2]))
    for ind, (lemma, pos) in enumerate(zip(new_matrix[:, lemma_id], new_matrix[:, pos_id])):
        if lemma == 0:
            lemma_pos_set.append(-1)
            continue
        lemma_pos_set.append(lemma_dict[lemma].decode('utf-8').lower()+"_"+pos_dict[pos])
        
    #return list(set(lemma_pos_set)), lemma_dict, pos_dict
    return lemma_pos_set, lemma_dict, pos_dict

# Restore exact lemma_pos
def get_lemma_pos_representation_for_single_sample(matrix, lemma_file, pos_file, lemma_id, pos_id):
    
    ind_to_lemma = pd.read_csv(lemma_file, sep='\t', header=None)
    ind_to_lemma.index = ind_to_lemma[0]
    del ind_to_lemma[0]
    lemma_dict = ind_to_lemma.to_dict()[1]

    ind_to_pos = pd.read_csv(pos_file, sep='\t', header=None)
    ind_to_pos.index = ind_to_pos[0]
    del ind_to_pos[0]
    pos_dict = ind_to_pos.to_dict()[1]
    
    lemma_pos_set = []
    for ind, (lemma, pos) in enumerate(zip(matrix[:, lemma_id], matrix[:, pos_id])):
        if lemma == 0:
            lemma_pos_set.append(-1)
            continue
        lemma_pos_set.append(lemma_dict[lemma].decode('utf-8').lower()+"_"+pos_dict[pos])
        
    #return list(set(lemma_pos_set)), lemma_dict, pos_dict
    return lemma_pos_set, lemma_dict, pos_dict

def get_word_to_ind_mapping(lemma_pos):
    # Get set of all train_words
    lemma_pos_set = list(set(lemma_pos))
    # Remove -1
    lemma_pos_set.remove(-1)
    # Create mapping: word to index
    word_to_ind = {word:ind+1 for ind, word in enumerate(lemma_pos_set)}
    word_to_ind[-1] = 0
    
    return word_to_ind

def get_matrix_with_lemma_pos_indexes(matrix, lemma_pos):
    # Reshape matrix to work only with words
    new_matrix = matrix.reshape((matrix.shape[0]*matrix.shape[1], matrix.shape[2]))
    # Get word to ind mapping
    word_to_ind = get_word_to_ind_mapping(lemma_pos)
    # Apply this mapping to all matrix samples
    train_w2v_indexes = [word_to_ind[word] for word in lemma_pos]
    # Update matrix with new applied mapping
    matrix_updated = np.concatenate((new_matrix, np.array(train_w2v_indexes).reshape(len(train_w2v_indexes), 1)), axis=1)
    matrix_updated = matrix_updated.reshape((matrix.shape[0], matrix.shape[1], matrix_updated.shape[1]))
    
    return matrix_updated

def get_w2v_embedding_weights(lemma_pos):
    # Get set of all train_words
    lemma_pos_set = list(set(lemma_pos))
    # Remove -1
    lemma_pos_set.remove(-1)
    
    train_word_indexes = [i+1 for i, cur_word in enumerate(lemma_pos_set)]
    weight_matrix = list()

    for cur_word_num in train_word_indexes:
        try:
            # init with w2v values for given word (lemma_pos)
            weight_matrix.append(w2v_model[train_words_set[cur_word_num]])
        except Exception, e:
            # init with random values from uniform distribution with -0.30, 0.30 range (min and max by w2v)
            weight_matrix.append(np.array([uniform(-0.30, 0.30) for i in range(300)]))
            continue
    weight_matrix_fin = np.zeros((np.shape(weight_matrix)[0]+1,np.shape(weight_matrix)[1]))
    weight_matrix_fin[1:,:] = np.array(weight_matrix)
    
    return weight_matrix_fin

# Create w2v embedding for matrix
def get_w2v_embedding(w2v_matrix):
    from keras.layers.embeddings import Embedding
    from keras.models import Sequential
    
    emb_model = Sequential()
    emb_model.add(Embedding(output_dim=w2v_matrix.shape[1], input_dim=w2v_matrix.shape[0], mask_zero=True, weights=[w2v_matrix]))
    
    return emb_model