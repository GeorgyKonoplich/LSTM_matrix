import pandas as pd
import numpy as np
import pickle

from sklearn.preprocessing import OneHotEncoder
from sklearn.cross_validation import train_test_split, ShuffleSplit
from sklearn.metrics import classification_report, precision_recall_fscore_support, accuracy_score
from sklearn.grid_search import GridSearchCV, ParameterGrid

from sklearn.externals.joblib import load, dump
from sklearn.metrics import f1_score, accuracy_score, recall_score, precision_score, confusion_matrix

def convert_result(y_true, pred):    
    res = {}
    res["classification_report"] = classification_report(y_true, pred)
    res["f1"] = f1_score(y_true, pred, pos_label=None, average="weighted")
    res["accuracy"] = accuracy_score(y_true, pred)
    res["precision"] = precision_score(y_true, pred, pos_label=None, average="weighted")
    res["recall"] = recall_score(y_true, pred, pos_label=None, average="weighted")
    res["confusion_matrix"] = confusion_matrix(y_true, pred)
    return res

def get_activation(activation):
    from keras.layers import Activation
    from keras.layers.advanced_activations import SReLU, PReLU, ELU
    
    if activation == 'srelu':
        return SReLU()
    elif activation == 'prelu':
        return PReLU()
    elif activation == 'elu':
        return ELU()
    else:
        return Activation(activation)
    

def create_stacked_lstm(branches, lstm_layers=[400, 400, 400], dense_layers=[100], loss='mse', output_dim=125, \
                 activation='tanh', optimizer='rmsprop', metrics='accuracy', dropout=0.3):
    
    from keras.models import Sequential
    from keras.layers import Activation, Dense, Dropout, LSTM, Merge
    from keras.layers.advanced_activations import SReLU, PReLU, ELU
    
    activation = get_activation(activation)

    final_model = Sequential()

    final_model.add(branches)
    
    # LSTM layers
    for ind, layer in enumerate(lstm_layers):
        final_model.add(Dropout(dropout))
        final_model.add(LSTM(layer, return_sequences=True if ind != len(lstm_layers)-1 else False))
    
    # Dense layers
    for ind, layer in enumerate(dense_layers):
        final_model.add(Dropout(dropout))
        final_model.add(Dense(layer))
        final_model.add(activation)
        
    final_model.add(Dropout(dropout))
    final_model.add(Dense(output_dim, activation = 'softmax'))

    final_model.compile(optimizer=optimizer, loss=loss, metrics=[metrics])
    
    return final_model

def create_mlp(branches, layers=[300, 150, 75], loss='mse', \
                 activation='tanh', optimizer='rmsprop', \
                 dropout=0.3, metrics='accuracy'):
    merged = Merge(branches, mode = 'concat')

    final_model = Sequential()

    final_model.add(merged)
    
    for layer in layers:
        final_model.add(Dense(layer, activation = activation))
        final_model.add(Dropout(dropout))
    
    final_model.add(Dense(target.shape[1], activation = 'softmax'))

    final_model.compile(optimizer=optimizer, loss=loss, metrics=[metrics])
    
    return final_model

def fit_model(model, X, y, callbacks=[], verbose=1, batch_size=4098, nb_epoch=20, validation_split=0.1):
    h = model.fit(X, y, verbose=verbose, batch_size=batch_size, nb_epoch=nb_epoch, \
                  validation_split=validation_split, callbacks=callbacks)
    return h

def get_stats(model, X, y):
    pred = model.predict_proba(X, batch_size=2048)
    return convert_result([np.argmax(row) for row in y], np.argmax(pred, axis=1))

def train_model(gpu_id, create_stacked_lstm, embedding, matrix, final_train_input, Y_train, x_val, y_val, param, stats=[]):
    import os
    os.environ["THEANO_FLAGS"] = "device="+gpu_id +",lib.cnmem=1"
    
    from keras.layers import Activation, Dense, Dropout, LSTM, Merge
    from keras.layers.embeddings import Embedding
    from keras.callbacks import EarlyStopping
    from keras.wrappers.scikit_learn import KerasClassifier
    
    branches = embedding(matrix)
    default_fit = {
    'nb_epoch': 1,
    'batch_size': 3072,
    'verbose': 1,
    'callbacks': [EarlyStopping(monitor='val_loss', patience=3)],
    'validation_data': [x_val, y_val]
    }    
    
    keras_model = KerasClassifier(build_fn=create_stacked_lstm, branches=branches, **param)
    keras_model.fit(final_train_input, Y_train, **default_fit)
    
    stats.append((param, get_stats(keras_model, x_val, y_val)))
    
def create_embedding_with_w2v_matrix(matrix, w2v_weights):
    branches = list()
    
    from keras.models import Sequential
    from keras.layers.embeddings import Embedding
    from keras.layers import Merge
    
    for param_num in range(matrix.shape[2]):
        temp_model = Sequential()

        embedding_max_index = np.max(matrix[:, :, param_num]) + 2

        if param_num == 1 or param_num == 7:
            embedding_out_size = 150
        elif param_num == 3:
            embedding_out_size = 10
        else:
            embedding_out_size = 3
        
        if param_num == matrix.shape[2]-1:
            temp_model.add(Embedding(w2v_weights.shape[0], w2v_weights.shape[1], \
                                     mask_zero=True, input_length=matrix.shape[1], weights=[w2v_weights]))
            branches.append(temp_model)
            merged = Merge(branches, mode = 'concat')
            
            return merged
        
        temp_model.add(Embedding(embedding_max_index, embedding_out_size, input_length=matrix.shape[1]))
        branches.append(temp_model)
        
    return merged

def create_embedding_without_w2v_matrix(matrix):
    branches = list()
    
    from keras.models import Sequential
    from keras.layers.embeddings import Embedding
    from keras.layers import Merge
    
    for param_num in range(matrix.shape[2]):
        temp_model = Sequential()

        embedding_max_index = np.max(matrix[:, :, param_num]) + 2

        if param_num == 1 or param_num == 7:
            embedding_out_size = 150
        elif param_num == 3:
            embedding_out_size = 10
        else:
            embedding_out_size = 3
        
        temp_model.add(Embedding(embedding_max_index, embedding_out_size, input_length=matrix.shape[1]))
        branches.append(temp_model)
        
    merged = Merge(branches, mode = 'concat')
    
    return merged

def matrix_train_val_test_split(matrix, target, number_of_samples_to_use=None, test_size=0.1, random_state=23):
    from sklearn.cross_validation import train_test_split
    
    if number_of_samples_to_use != None:
        temp_train = matrix[:number_of_samples_to_use]
        temp_target = target[:number_of_samples_to_use]
        
        train_samples = int(temp_train.shape[0]*0.9)
        X_train = temp_train[:train_samples]
        X_test = temp_train[train_samples:]
        
        y_train = temp_target[:train_samples]
        y_test = temp_target[train_samples:]
        
    else:
        train_samples = int(matrix.shape[0]*0.9)
        X_train = matrix[:train_samples]
        X_test = matrix[train_samples:]
        
        y_train = target[:train_samples]
        y_test = target[train_samples:]
        
    X_train, X_val, y_train, y_val = train_test_split(X_train, y_train, test_size=test_size, random_state=random_state)
    print(X_train.shape, X_val.shape, X_test.shape, y_train.shape, y_val.shape, y_test.shape)
    
    
    return  [X_train[:,:,i] for i in range(X_train.shape[2])], \
            [X_val[:,:,i] for i in range(X_val.shape[2])], \
            [X_test[:,:,i] for i in range(X_test.shape[2])], \
            y_train, y_val, y_test
            
def save_keras_model(keras_model, file_path):
    pickle.dump([keras_model.to_json(), keras_model.get_weights()], open(file_path, 'wb'))

def load_keras_model(file_path):
    from keras.models import model_from_json
    json_string, weights = pickle.load(open(file_path, 'rb'))
    keras_model = model_from_json(json_string)
    keras_model.set_weights(weights)
    return keras_model

# Gridsearch for keras models. Works only on one gpu
def keras_gridsearch(network_topology, branches, \
                     X_train, y_train, \
                     X_val, y_val, \
                     X_test, y_test, \
                     params, fit_params, \
                     save_best_model=None, \
                     save_results=None, start=None, end=None
                     ):
    from keras.wrappers.scikit_learn import KerasClassifier
    results = []
    best_score = 0
    best_model = 0

    for param in list(ParameterGrid(params))[start:end]:
        try:
            keras_model = KerasClassifier(build_fn=network_topology, branches=branches, **param)
            keras_model.fit(X_train, y_train, **fit_params)
            stats_val = get_stats(keras_model, X_val, y_val)
            stats_test = get_stats(keras_model, X_test, y_test)
            results.append((param, stats_val, stats_test))

            if best_score <= stats_val['f1']:
                best_score = stats_val['f1']
                best_model = keras_model
            
                if save_best_model != None:
                    save_keras_model(best_model.model, save_best_model)
                if save_results != None:
                    pickle.dump(results, open(save_results, 'wb'))
                
        except Exception, e:
            print(e)
            continue
                    
    return results, best_model, best_score